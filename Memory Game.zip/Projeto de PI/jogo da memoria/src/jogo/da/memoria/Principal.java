/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jogo.da.memoria;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author Renata
 */
public class Principal extends javax.swing.JFrame {
    
    //Adiciona as imagens no programa.
    ImageIcon arara = new ImageIcon("Arara.jpg");
    ImageIcon borboleta = new ImageIcon("Borboleta.jpg");
    ImageIcon cachorro = new ImageIcon("Cachorro.jpg");
    ImageIcon coruja = new ImageIcon("Coruja.jpg");
    ImageIcon gato = new ImageIcon("Gato.jpg");
    ImageIcon leao = new ImageIcon("Leao.jpg");
    ImageIcon macaco = new ImageIcon("macaco.jpg");
    ImageIcon peixe = new ImageIcon("peixe.jpg");
    ImageIcon a = new ImageIcon("1.jpg");
    ImageIcon b = new ImageIcon("2.jpg");
    ImageIcon c = new ImageIcon("3.jpg");
    ImageIcon d = new ImageIcon("4.jpg");
    ImageIcon e = new ImageIcon("5.jpg");
    ImageIcon f = new ImageIcon("6.jpg");
    ImageIcon g = new ImageIcon("7.jpg");
    ImageIcon h = new ImageIcon("8.jpg");
    ImageIcon i = new ImageIcon("9.jpg");
    ImageIcon j = new ImageIcon("10.jpg");
    ImageIcon l = new ImageIcon("11.jpg");
    ImageIcon m = new ImageIcon("12.jpg");
    ImageIcon n = new ImageIcon("13.jpg");
    ImageIcon o = new ImageIcon("14.jpg");
    ImageIcon p = new ImageIcon("15.jpg");
    ImageIcon q = new ImageIcon("16.jpg");
    
    //Vetor de números aleatórios
    int [] ale = new int[16];
    
    //Vetor com o nome das imagens.
    ImageIcon[] imagens = new ImageIcon[16];
    
    //pontos do jogador
    int pontos = 0;
    
    //Acertos do jogador
    int acertos = 0;
    
    String nome; //Nome do Jogador
    
    /**
     * Creates new form Principal
     */
    public Principal() {
        initComponents();
        
        //Vetor com o nome das imagens.
        imagens[0] = imagens[8]  = arara;
        imagens[1] = imagens[9] = borboleta;
        imagens[2] = imagens[10] = cachorro;
        imagens[3] = imagens[11] = coruja;
        imagens[4] = imagens[12] = gato;
        imagens[5] = imagens[13] = leao;
        imagens[6] = imagens[14] = macaco;
        imagens[7] = imagens[15] = peixe;
        
        //Adicionando o nome no jogo
        BufferedReader leitura;
        String arquivo = "log.txt";
        try{
            leitura = new BufferedReader(new FileReader(arquivo));
            while(leitura.ready()){
                String linha = leitura.readLine();
                nome = linha;
                
            }
            leitura.close();
        }catch(Exception e){
            System.out.println("Erro na leitura");
        }
        jLabel23.setText(nome);
        
        colocarimagens(imagens);
        
        
    }
    //Função para colocar a imagem no Jlabel
    private void colocarimagens(ImageIcon imagens[]){
        //Vetor de números aleatórios
        //int [] ale = new int[16];
        int x;
        boolean comp = false;
        for(int i = 0; i < ale.length;){
            int rand = (int)(Math.random()*16);
            //garantia que todas os valores do vetor sejam diferentes.
            for(int j = 0; j < i; j++){
                if(ale[j] == rand){
                    comp = true;
                    break;
                }
            }
            if(comp == false){
                ale[i]=rand;
                i++;
            }
            comp = false;
            
            
        }
        for(int i = 0; i < ale.length; i++){
           System.out.println(ale[i]); 
        }
        
        //Inicia o jogo com as imagens
        for(int i = 1; i <= ale.length; i++){
           LabelFigura(i, false); 
        }
        
        
        
    }
    
    
    //Alterna entre mostrar ou não a figura
    private void LabelFigura(int label, boolean mostrar){
        switch (label){
            case 1 :
                if (mostrar == true){
                    jLabel1.setIcon(imagens[ale[0]]);
                }
                if (mostrar == false){
                    jLabel1.setIcon(a);
                }
                break;
            case 2 :
                if (mostrar == true){
                    jLabel2.setIcon(imagens[ale[1]]);
                }
                if (mostrar == false){
                    jLabel2.setIcon(b);
                }
                break;
            case 3 :
                if (mostrar == true){
                    jLabel3.setIcon(imagens[ale[2]]);
                }
                if (mostrar == false){
                    jLabel3.setIcon(c);
                }
                break;
            case 4 :
                if (mostrar == true){
                    jLabel4.setIcon(imagens[ale[3]]);
                }
                if (mostrar == false){
                    jLabel4.setIcon(d);
                }
                break;
            case 5 :
                if (mostrar == true){
                    jLabel5.setIcon(imagens[ale[4]]);
                }
                if (mostrar == false){
                    jLabel5.setIcon(e);
                }
                break;
            case 6 :
                if (mostrar == true){
                    jLabel6.setIcon(imagens[ale[5]]);
                }
                if (mostrar == false){
                    jLabel6.setIcon(f);
                }
                break;
            case 7 :
                if (mostrar == true){
                    jLabel7.setIcon(imagens[ale[6]]);
                }
                if (mostrar == false){
                    jLabel7.setIcon(g);
                }
                break;
            case 8 :
                if (mostrar == true){
                    jLabel8.setIcon(imagens[ale[7]]);
                }
                if (mostrar == false){
                    jLabel8.setIcon(h);
                }
                break;
            case 9 :
                if (mostrar == true){
                    jLabel9.setIcon(imagens[ale[8]]);
                }
                if (mostrar == false){
                    jLabel9.setIcon(i);
                }
                break;
            case 10 :
                if (mostrar == true){
                    jLabel10.setIcon(imagens[ale[9]]);
                }
                if (mostrar == false){
                    jLabel10.setIcon(j);
                }
                break;
            case 11 :
                if (mostrar == true){
                    jLabel11.setIcon(imagens[ale[10]]);
                }
                if (mostrar == false){
                    jLabel11.setIcon(l);
                }
                break;
            case 12 :
                if (mostrar == true){
                    jLabel12.setIcon(imagens[ale[11]]);
                }
                if (mostrar == false){
                    jLabel12.setIcon(m);
                }
                break;
            case 13 :
                if (mostrar == true){
                    jLabel13.setIcon(imagens[ale[12]]);
                }
                if (mostrar == false){
                    jLabel13.setIcon(n);
                }
                break;
            case 14 :
                if (mostrar == true){
                    jLabel14.setIcon(imagens[ale[13]]);
                }
                if (mostrar == false){
                    jLabel14.setIcon(o);
                }
                break;
            case 15 :
                if (mostrar == true){
                    jLabel15.setIcon(imagens[ale[14]]);
                }
                if (mostrar == false){
                    jLabel15.setIcon(p);
                }
                break;
            case 16 :
                if (mostrar == true){
                    jLabel16.setIcon(imagens[ale[15]]);
                }
                if (mostrar == false){
                    jLabel16.setIcon(q);
                }
                break;
        }
    }
    
    //Alterna entre mostrar ou não a figura
    private void Labelbyebye(int label){
        switch (label){
            case 1 :
                
                jLabel1.setVisible(false);
                break;
            case 2 :
                jLabel2.setVisible(false);
                break;
            case 3 :
                jLabel3.setVisible(false);
                break;
            case 4 :
                jLabel4.setVisible(false);
                break;
            case 5 :
                jLabel5.setVisible(false);
                break;
            case 6 :
                jLabel6.setVisible(false);
                break;
            case 7 :
                jLabel7.setVisible(false);
                break;
            case 8 :
                jLabel8.setVisible(false);
                break;
            case 9 :
                jLabel9.setVisible(false);
                break;
            case 10 :
                jLabel10.setVisible(false);
                break;
            case 11 :
                jLabel11.setVisible(false);
                break;
            case 12 :
                jLabel12.setVisible(false);
                break;
            case 13 :
                jLabel13.setVisible(false);
                break;
            case 14 :
                jLabel14.setVisible(false);
                break;
            case 15 :
                jLabel15.setVisible(false);
                break;
            case 16 :
                jLabel16.setVisible(false);
                break;
        }
    }
    
    //Calcula as posições escolhidas para ver se a figura é igual
    private boolean comparar(int p1, int p2){
        int x = ale[p1] - ale[p2];
        
        if (x == ale.length/2 || -x == ale.length/2){
            return true;
        }
        return false;
        
        
    }
    //Aumenta os pontos do jogador
    private void PontosUpdate(boolean x){
        if(x == true){
            pontos++;
        }
        if(x == false){
            pontos--;
        }
        
        jLabel20.setText(Integer.toString(pontos));
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jComboBox2 = new javax.swing.JComboBox();
        jButton1 = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("jLabel1");

        jLabel2.setText("jLabel2");

        jLabel3.setText("jLabel3");

        jLabel4.setText("jLabel4");

        jLabel5.setText("jLabel1");

        jLabel7.setText("jLabel3");

        jLabel9.setText("jLabel1");

        jLabel10.setText("jLabel2");

        jLabel11.setText("jLabel1");

        jLabel12.setText("jLabel1");

        jLabel13.setText("jLabel13");

        jLabel14.setText("jLabel14");

        jLabel15.setText("jLabel15");

        jLabel16.setText("jLabel16");

        jLabel6.setText("jLabel2");

        jLabel8.setText("jLabel4");

        jLabel17.setText("Selecione duas figuras");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16"}));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16" }));

        jButton1.setText("OK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel19.setBackground(new java.awt.Color(0, 255, 255));
        jLabel19.setText("Quantidade de Pontos:");

        jLabel20.setBackground(new java.awt.Color(0, 255, 255));
        jLabel20.setText("Pontos");

        jLabel23.setText("jLabel23");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(700, 700, 700)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jLabel20))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(31, 31, 31)
                                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(24, 24, 24)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGap(18, 18, 18)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel17)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jButton1))))))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(11, 11, 11)
                                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(8, 8, 8)
                                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(11, 11, 11)
                                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(0, 1, Short.MAX_VALUE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel17)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton1))
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        boolean comp = comparar(jComboBox1.getSelectedIndex(), jComboBox2.getSelectedIndex());
        
        //Compara as duas escolhas.
        if (jComboBox1.getSelectedIndex() == jComboBox2.getSelectedIndex()){
            JOptionPane.showMessageDialog(null,"Você não pode escolher a mesma figura duas vezes");
        }else{
            if(comp == true){
                LabelFigura(jComboBox1.getSelectedIndex()+1, true);
                LabelFigura(jComboBox2.getSelectedIndex()+1, true);
                JOptionPane.showMessageDialog(null,"Parabéns, você acertou");
                PontosUpdate(true);
                acertos++;
                Labelbyebye(jComboBox1.getSelectedIndex()+1);
                Labelbyebye(jComboBox2.getSelectedIndex()+1);
                
            }else{
                LabelFigura(jComboBox1.getSelectedIndex()+1, true);
                LabelFigura(jComboBox2.getSelectedIndex()+1, true);
                JOptionPane.showMessageDialog(null,"Infelizmente você errou");
                PontosUpdate(false);
                LabelFigura(jComboBox1.getSelectedIndex()+1, false);
                LabelFigura(jComboBox2.getSelectedIndex()+1, false);
            }

            if(acertos == 8){
                JOptionPane.showMessageDialog(null,"O jogo acabou");
                //Grava a pontuação do jogador no arquivo
                String arquivo;
                BufferedWriter gravar;
                arquivo = "ultimosjogos.txt";
                try{
                    //Abre o arquivo para a gravação
                    gravar = new BufferedWriter(new FileWriter(arquivo, true));
                    gravar.write(pontos+ " " +nome);
                    gravar.newLine();
                    gravar.close();
                }catch(Exception e){
                    System.out.println("Erro na abertura do arquivo");
                }
                System.exit(0);
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
